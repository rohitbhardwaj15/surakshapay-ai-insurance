# SurakshaPay

SurakshaPay is an AI-powered parametric micro-insurance platform for Q-Commerce delivery partners (Zepto/Blinkit). It protects weekly income against hyperlocal disruptions and demonstrates:

- Zero-touch claim automation
- AI-driven risk score and premium calculation
- Parametric trigger processing
- Fraud prevention with manual review threshold
- Insurance compliance logic (coverage cap, exclusions, basis-risk handling)

## Tech Stack

- Frontend: React + Vite
- Backend: Node.js + Express
- Data: JSON datastore (`backend/data/db.json`) for prototype persistence
- Deployment target: Vercel (frontend + backend as separate projects)

## Project Structure

```txt
backend/
  api/index.js
  src/app.js
  src/server.js
  src/engine.js
  src/store.js
  data/db.json
frontend/
  src/pages/*
  src/context/UserContext.jsx
  src/api.js
```

## Features Implemented

1. Home page with SurakshaPay intro, CTA, and coverage exclusions.
2. Registration page with name, city, platform, weekly income.
3. Dashboard with profile, weekly income, AI risk score, premium, coverage, policy status.
4. Policy page with premium breakdown, 70% cap details, activate/deactivate controls.
5. Trigger simulation panel for:
   - Rainfall > 35mm
   - AQI > 350
   - Heatwave > 44C
   - Curfew alert
   - Flood alert
6. Claims page with pending/approved status, payout amount, timestamp, auto-processing message.
7. Fraud status indicator:
   - `Fraud Check Passed`
   - `Under Review` if `fraud_score > 0.75`
8. Optional admin panel with total claims, fraud alerts, payouts, and risk heatmap summary.

## Insurance Logic Included

- Dynamic premium formula: `premium = base_rate x (1 + risk_score)` where `base_rate = 4% of weekly income`.
- Coverage cap: `70%` of weekly income (moral hazard control).
- No payout when inactive before trigger (activity eligibility window).
- Repeated-claim and device/location pattern checks.
- Basis risk handling:
  - Zone-based validation (`city` match)
  - Time-aligned trigger validation (`timeAlignedWithShift`)
  - Multi-factor trigger conditions
- Exclusions:
  - War / armed conflict / riots
  - Pandemics
  - Nationwide lockdowns
  - Platform-wide outages
  - Large disasters (earthquakes, cyclones)
- Fail-safe:
  - Trigger verification buffer (`verificationBufferSeconds`)
  - Duplicate claim protection
  - Manual review for high fraud score

## Local Run

### 1) Backend

```bash
cd backend
npm install
npm run dev
```

Backend runs on `http://localhost:4000`.

### 2) Frontend

```bash
cd frontend
npm install
npm run dev
```

Frontend runs on `http://localhost:5173` and uses `VITE_API_URL` (default: `http://localhost:4000`).

## Demo Flow

1. Register partner
2. Policy auto-created with AI risk score and dynamic premium
3. Activate policy in Policy page
4. Simulate trigger (rain/aqi/heatwave/curfew/flood)
5. Claim auto-processed in backend
6. Open Claims page for status + payout + fraud result

## Vercel Deployment

Deploy as two Vercel projects (recommended):

### Backend Deploy

```bash
cd backend
npm i -g vercel
vercel
vercel --prod
```

- Entry point is `backend/api/index.js` (Express serverless).
- Save deployed backend URL, for example:
  - `https://surakshapay-api.vercel.app`

### Frontend Deploy

```bash
cd frontend
vercel
vercel --prod
```

Set environment variable in Vercel frontend project:

- `VITE_API_URL=https://surakshapay-api.vercel.app`

Redeploy frontend after setting env var.

## GitHub Push

```bash
git add .
git commit -m "Build SurakshaPay full-stack parametric micro-insurance platform"
git branch -M main
git remote add origin <your-github-repo-url>
git push -u origin main
```

## ZIP Package

Run from project root:

```powershell
Compress-Archive -Path .\* -DestinationPath .\SurakshaPay-source.zip -Force
```

This generates a complete source zip at:

- `SurakshaPay-source.zip`
